<?php
/***************************************************************************
 *			mapbbcode_addons.php
 *			--------------------
 *	begin				: 29/11/2013
 *	copyright			: Zverik
 *	email				: zverik@textual.ru
 *
 *	version				: 1.0.0 - 29/11/2013
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software under WTFPL license;
 *   do whatever you want with it.
 *
 ***************************************************************************/

$lang['MapBB_JS_Addons'] = '';
// put MapBBCode add-ons here
$lang['MapBB_JS_Addons'] .= '<script src="%base%/proprietary/Bing.js"></script>';
//$lang['MapBB_JS_Addons'] .= '<script src="%base%/proprietary/Esri.js"></script>';
//$lang['MapBB_JS_Addons'] .= '<script src="%base%/proprietary/Google.js"></script>';
//$lang['MapBB_JS_Addons'] .= '<script src="%base%/proprietary/Yandex.js"></script>';
//$lang['MapBB_JS_Addons'] .= '<script src="%base%/Handler.Length.js"></script>';

// You should also change includes/mapbbcode/mapbbcode-window.html accordingly!

?>
